<script>
  var toggle=0;
  var front=document.querySelector(".brainfront1");
  var ply=document.getElementById("play");
  var obj={};
  obj.fun=function () {
    if(toggle%2==0){
    document.getElementById("braintext").style.opacity='0';
    var ele=document.querySelectorAll(".brainfront")
    var i=0;
    for(i=0;i<ele.length;i++){
    ele[i].style.transform="translate(-300px,0)";}
    var el=document.getElementById("aboutUs");
    el.style.opacity = '1'
    el.style.webkitAnimationPlayState="running";
    el.style.animationPlayState = 'running';
    var el2=document.getElementById("abouttext");
    el2.style.opacity = '1';
    el2.style.transform='translate(0,180px)';
    el2.style.background = 'rgba(0,0,0,0.5)';
  }
  else{
    document.getElementById("braintext").style.opacity='1';
    var ele=document.querySelectorAll(".brainfront")
    var i=0;
    for(i=0;i<ele.length;i++){
    ele[i].style.transform="translate(20px,0)";}

     var el=document.getElementById("aboutUs");
    el.style.opacity = '0';
    el.style.webkitAnimationPlayState="paused";
    el.style.animationPlayState = 'paused';
    var el2=document.getElementById("abouttext");
    el2.style.opacity = '0';

  }
  toggle++;
  }



  obj.fun1=function () {
    /* body... */
    window.location.href="animations.php"
  }
  front.addEventListener("click",obj.fun, false);
  ply.addEventListener("click", obj.fun1, false);
  var slideIndex = 0;
showSlides();

function plusSlides(n) {
showSlides();
}

function currentSlide(n) {
showSlides();
}


function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
     slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 5000); // Change image every 2 seconds
}
</script>

</body>
</html>
