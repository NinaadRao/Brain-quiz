<div id="footer"><div id="Information"><p>&nbsp  Information</p>
    <a href="#" class="footer">> Home</a>
    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp

    &nbsp &nbsp
    <br>
    <a href="announcements.php" class="footer">> Events</a><br>
    <a href="news.php" class="footer">> News</a><br>
   
    <a href="competitions.php" class="footer">> Upcoming</a><br>
    <a href="login/profile.php" class="footer">> Results</a>
    </div>

    <div id="contactus"><p>Contact Us</p>
      100 Feet Ring Road,<br>
 BSK III Stage,<br>
 Bangalore-560085<br>
 +91 8023456789<br>
 +91 8024365987
</div>
<div id="creator"><p>Webpage Creators</p>
      &nbsp &nbsp > Mehul Garg<br>
      &nbsp &nbsp > Ninaad R. Rao<br>
      &nbsp &nbsp > P. Abhishikta Sai<br>
</div>
</div>