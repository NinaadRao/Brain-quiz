<?php
include 'h2.php';
include 'login/db.php';
$email = $_SESSION['email'];
	if($_SESSION['option'] == 1){
		$i = 0;
		array_push($_SESSION['chosen'],$_POST['answer']);
		while($i < 8){
			if($_SESSION['chosen'][$i] == $_SESSION['correct'][$i])
			$_SESSION['easy']++;
			$i++;
		}
		// $q = "UPDATE `easyquestions` set easy = easy+$answer where email= '$email'";
		$answer = $_SESSION['easy'];
		$mysqli->query("UPDATE `users` set easy = easy+$answer where email= '$email'");
		$percent = ($answer/8)*100;
	}
	elseif($_SESSION['option'] == 2){
		$i = 0;
		array_push($_SESSION['chosen'],$_POST['answer']);
		while($i < 8){
			if($_SESSION['chosen'][$i] == $_SESSION['correct'][$i])
			$_SESSION['medium']++;
			$i++;
		}
		$answer = $_SESSION['medium'];
		$percent = ($answer/8)*100;
		$mysqli->query("UPDATE `users` set medium = medium+$answer where email= '$email'");
	}
	elseif($_SESSION['option'] == 3){
		$i = 0;
		array_push($_SESSION['chosen'],$_POST['answer']);
		while($i < 8){
			if($_SESSION['chosen'][$i] == $_SESSION['correct'][$i])
			$_SESSION['hard']++;
			$i++;
		}
		$answer = $_SESSION['hard'];
		$percent = ($answer/8)*100;
		$mysqli->query("UPDATE `users` set hard = hard+$answer where email= '$email'");
	}
?>
<html>
<head>
	<title></title>
</head>
<style type="text/css">
body { background-image:url("dark_spots_texture_background_50355_2558x1562.jpg"); animation}
#results { width:50%; height:70%; background-color: rgba(255,255,255,0.5); position: absolute; top:30%; left:25%;}
#title {font-size: 50px; color:white; text-align: center;}
#attempted {font-size: 30px; text-align: center;}
#number {font-size: 30px; }
#marks {font-size: 30px; }
#percent {font-size: 50px; text-align: center; color:green;}
</style>
<body>
	<p id="title">Results</p>
	<div id="results"><p id="attempted">You Attempted</p><br>
		<p id="number">  &nbsp &nbsp	&nbsp &nbspNumber of questions:8</p>
		<p id="marks">  &nbsp &nbsp	&nbsp &nbspMarks:<?=$answer?>/8</p>
		<p id = "marks">&nbsp &nbsp	&nbsp With a success rate of</p>
		<p id='percent'><?=$percent?>%</p>
	</div>
	<?php
	//echo $_SESSION['easy'];
	unset($_SESSION['chosen']);
	unset($_SESSION['correct']);
	// unset($_SESSION['easy']);
	// unset($_SESSION['medium']);
	// unset($_SESSION['hard']);
	?>
</body>
</html>
