	<?php
if(!isset($_SESSION)){
	session_start();
}
?>
<html>
<head>
	<title>webpage
	</title>
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>
<style type="text/css">
@font-face {
    font-family:"Arvo";
    src:url("fonts/arvo/Arvo-Bold.ttf");
  }
body { font-family: "Arvo";
background-image: url("dark_spots_texture_background_50355_2558x1562.jpg");
}
body { background-image:url("dark_spots_texture_background_50355_2558x1562.jpg");} font-family: "Arvo";margin:0; overflow-x: hidden;
color: white;
}
nav { background-color:rgba(0,0,0,.5); font-size: 25px;}
nav a { color: white; display: inline-block; text-decoration: none; position:relative; padding-left: 4px; padding-right: 4px;}
nav a:hover { color:rgba(255,255,255,0.5);text-align: center; }
nav>ul>li>ul {list-style-type: none; text-align: center; padding-left: 4px; padding-right:  4px;}
nav > ul > li { display: inline-block; text-align: center; padding-left: 4px; padding-right: 4px;}
nav > ul { list-style-type: none; padding-left: 4px; padding-right: 4px;}
.sub-menu-parent a{
	position: relative;
	left:5%;
	text-align: center;
	padding:10px 10px 10px 10px; }

	.sub-menu-parent2{
		position: relative;
		float: right;
		right: 7%;
		/*left:5%;*/
		/*float: right;*/
		text-align: center;
		padding:10px 10px 10px 10px; }

	.sub-menu {
		visibility: hidden; /* hides sub-menu */
		opacity: 0;
		position: absolute;
		/*padding:1px 1px 1px 1px;
		*/
		top: 100%;
		left: 5%;
		width: 150%;
		text-align: center;
		transform: translateY(-2em);
		z-index: -1;
		transition: all 0.3s ease-in-out 0s, visibility 0s linear 0.3s, z-index 0s linear 0.01s;
	}
	.sub-menu-parent:hover {
		position: relative;
		padding-top:
		padding-left:10px;

		/*margin:1px 1px 1px 1px;*/
		border-radius: 5px;
		color: #4CAF50;
	}
		.sub-menu-parent:hover .sub-menu {
			visibility: visible; /* shows sub-menu */
			opacity: 1;
			z-index: 1;
			border-radius: 20px;
			padding: 1px 1px 1px 1px;
			text-align: center;
			transform: translateY(0%);
			transition-delay: 0s, 0s, 0.3s; /* this removes the transition delay so the menu will be visible while the other styles transition */
		}
		.sub-menu {

			text-align: center;
		}
		#login{
			padding: 0;
			position: relative;
			left:600%;
		}
		#login:hover{
			background: green;
			opacity: 40;
		}
		.sub-menu2 {
			visibility: hidden; /* hides sub-menu */
			opacity: 0;
			position: absolute;
			/*padding:1px 1px 1px 1px;
			*/
			top: 100%;
			left: 5%;
			width: 150%;
			text-align: center;
			transform: translateY(-2em);
			z-index: -1;
			transition: all 0.3s ease-in-out 0s, visibility 0s linear 0.3s, z-index 0s linear 0.01s;
		}
		.sub-menu-parent2:hover {
			position: relative;
			padding-top:
			padding-left:10px;

			/*margin:1px 1px 1px 1px;*/
			border-radius: 5px;
			color:black;
		}
			.sub-menu-parent2:hover .sub-menu2 {
				visibility: visible; /* shows sub-menu */
				opacity: 1;
				z-index: 1;
				border-radius: 20px;
				padding: 1px 1px 1px 1px;
				text-align: center;
				transform: translateY(0%);
				transition-delay: 0s, 0s, 0.3s; /* this removes the transition delay so the menu will be visible while the other styles transition */
			}
			.sub-menu2 {

				text-align: center;
			}
		/*#sign{
		position:relative;
		left:730%;

		}*/

		.color {
			/*position: ;
			*/    display: inline-block;
			width: 100%;
			line-height: 2em;
			text-align: center;
			text-decoration: none;
			border-radius: 5px;
		}
		.color:hover {
			color: white;
			background-color: #4CAF50;
		}

	</style>
	<body>


		<nav>
			<ul>
				<li><a class = "color" href  = "brainquiz.php">Home</a></li>
				<li><a class="color" href="animations.php" name = "quiz">Quiz</a></li>
				<li><a  class='color' href="news.php">News</a></li>


				<li><a href="competitions.php" class="color">Competitions</a></li>
				<!-- <li><a href="#" class="color"></a></li> -->
				<!-- <li><a href="#" class="color">Events</a></li> -->

				<li><a  class='color' href="announcements.php">Announcements</a></li>
				<li class="sub-menu-parent"><a href="#">Rules</a>
					<ul class="sub-menu">
						<li><a class='color' href="Easy.php">Easy</a></li>
						<li><a  class='color' href="Medium.php">Medium</a></li>
						<li><a class='color' href="Hard.php">Hard</a></li>
					</ul>
				</li>
				<li class = "sub-menu-parent2"><?php
				if(isset($_SESSION['logged_in'])){
					if($_SESSION['logged_in'] == false){
						echo '<a href="login/profile.php" class="sub-menu-parent2">Login</a></li>';
					}
					elseif($_SESSION['logged_in'] == true){
						echo '<a href="#">'.$_SESSION["first_name"].'</a>
						<ul class="sub-menu2">
							<li><a class="color" href="pr.php">View Profile</a></li>
							<li><a  class="color" href="login/logout.php">Logout</a></li>
						</ul>
						</li>';
					}
				}
				else {
					echo '<a href="login/profile.php" class="sub-menu-parent2">Login</a></li>';
				}
				?>
			<!--	<li>
				<?php
				if(isset($_SESSION['logged_in'])){
					if($_SESSION['logged_in'] == true){
						echo '<a href="profile.php" class="color" id="Name">'.$_SESSION['first_name'].'<a></li>';
					}
				}
					?>-->
				</ul>


			</nav>
