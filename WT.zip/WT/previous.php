<?php
include 'h2.php';
// $p = $_SESSION['prevquestion'];
$_SESSION['counter']--;
$_SESSION['prevcounter']--;
echo "<script>
      window.location.href ='Easyquestions.php';
      </script>    ";
 ?>
 <!-- <link type = "text/css" rel="stylesheet" href="try.css">
  <div class= "ques" style="border: none;">
    <div class= "side">
    </div>
    <div class="wrap">
      <p><?= $p['question']?>
        <br/><br/></p>
      </div>
      <div class = "ans">
        <form action = "Easyquestions.php" method = "POST">
          <button class="btn-6" type = "submit" value="<?=$p['option1']?>" name = "answer"><?=$p['option1']?><span></span></button>
          <button class="btn-6" type = "submit" value="<?=$p['option2']?>" name = "answer"><?=$p['option2']?><span></span></button>
          <button class="btn-6" type = "submit" value="<?=$p['option3']?>" name = "answer"><?=$p['option3']?><span></span></button>
          <button class="btn-6" type = "submit" value="<?=$p['option4']?>" name = "answer"><?=$p['option4']?><span></span></button>
          <a href="login/logout.php" class="btn-6">Logout</a> -->
        <!--  <a href = "easyquestions.php?op=1" class = "btn-6">Previous</a>
        </form>
      </div>
    </div>
  </body>
  </html>-->
