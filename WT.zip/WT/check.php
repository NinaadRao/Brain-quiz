<?php
session_start();
$_SESSION['prevcounter'] = 0;
if(isset($_GET['option'])){
  $_SESSION['sessionquestions'] = array();
  $option = $_GET['option'];
  $_SESSION['option'] = $option;
  echo $option;
  if($_SESSION['logged_in'] == true){
    if($option == '1'){
      $_SESSION['easy'] = 0;
      $_SESSION['counter'] = 0;
      $_SESSION['correct'] = array();
      $_SESSION['chosen'] = array();
      $_SESSION['option'] = 1;
      if (!isset($_COOKIE[$cookie_name])){
        setcookie($cookie_name, $cookie_value, $cookie_expir, '/');
        header("location: Easyquestions.php");
      }
      else {
        header("location: animations.php");
      }
    }
    elseif ($option == '2') {
      $_SESSION['counter'] = 0;
      $_SESSION['medium'] = 0;
      $_SESSION['option'] = 2;
      $_SESSION['correct'] = array();
      $_SESSION['chosen'] = array();
      if (!isset($_COOKIE[$cookie_name])){
        setcookie($cookie_name, $cookie_value, $cookie_expir, '/');
        header("location: Mediumquestions.php");
      }
      else {
        $_SESSION['counter'] = 0;
        $_SESSION['option'] = 1;
        header("location: animations.php");
      }
    }
    elseif ($option == '3') {
      $_SESSION['hard'] = 0;
      $_SESSION['correct'] = array();
      $_SESSION['chosen'] = array();
      if (!isset($_COOKIE[$cookie_name])){
        setcookie($cookie_name, $cookie_value, $cookie_expir, '/');
        header("location: Hardquestions.php");
      }
      else {
        header("location: animations.php");
      }
    }
  }
  else{
    if($option == '1'){
      $_SESSION['correct'] = array();
      $_SESSION['chosen'] = array();
      $_SESSION['easy'] = 0;
      $_SESSION['counter'] = 0;
      $_SESSION['option'] = 1;
      header("location: login/index.php");
    }
    if($option == '2'){
      $_SESSION['medium'] = 0;
      $_SESSION['counter'] = 0;
      $_SESSION['option'] = 2;
      $_SESSION['correct'] = array();
      $_SESSION['chosen'] = array();
      header("location: login/index.php");
    }
    if($option == '3'){
      $_SESSION['hard'] = 0;
      $_SESSION['counter'] = 0;
      $_SESSION['option'] = 3;
      $_SESSION['correct'] = array();
      $_SESSION['chosen'] = array();
      header("location: login/index.php");
    }
  }
}
else{
  header("location: brainquiz.php");
}

?>
