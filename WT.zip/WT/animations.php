<?php
include 'h2.php';
if(!isset($_SESSION)){ session_start();}
// session_start();
//$_SESSION['option'] = 0;
$cookie_name = 'cookie';
$cookie_value = 'redirection';
$cookie_expire = time() + 28800;
?>

<link rel="stylesheet" href="brain.css">

<body><a href = "check.php?option=1" >
	<div class="beginner">

		<div>
			<img src="brain\brain-top-base.png" class="img1"></div>

			<img src="brain\brain-river-beg-red.png" class="img2">
			<img src="brain\brain-river-beg-fire.png" class="img3">
			<img src="brain\brain-river-beg-blue.png" class="img4">


			<img src="brain\brain-top-synaps-1.png" class="img5">
			<img src="brain\brain-top-synaps-2.png" class="img6">
			<img src="brain\brain-top-synaps-3.png" class="img7">
			<img src="brain\brain-top-synaps-4.png" class="img8">
			<img src="brain\brain-top-line-1.png" class="img9">

			<img src="brain\brain-top-line-2.png" class="img10">
			<img src="brain\brain-top-line-3.png" class="img11">
			<img src="brain\brain-top-line-4.png" class="img12">

			<img src="brain\brain-raise-beg-firelines.png" class="img13">
			<img src="brain\brain-raise-beg-fire.png" class="img14">
			<img src="brain\brain-raise-beg-fire.png" class="img15">
			<img src="brain\brain-top-laser.png" class="img16">
			<img src="brain\brain-all-beg-fire.png" class="img17">

			<h1  id="beg" style="display: none" > Beginner</h1>


		</div>
	</a>
	<a href="check.php?option=2">
		<div class="Amateur">
			<div>
				<img src="brain\brain-top-base.png" class="img1"></div>

				<img src="brain\brain-river-beg-red.png" class="img2">
				<img src="brain\brain-river-beg-fire.png" class="img3">
				<img src="brain\brain-river-beg-blue.png" class="img4">


				<img src="brain\brain-top-synaps-1.png" class="img5">
				<img src="brain\brain-top-synaps-2.png" class="img6">
				<img src="brain\brain-top-synaps-3.png" class="img7">
				<img src="brain\brain-top-synaps-4.png" class="img8">
				<img src="brain\brain-top-line-1.png" class="img9">

				<img src="brain\brain-top-line-2.png" class="img10">
				<img src="brain\brain-top-line-3.png" class="img11">
				<img src="brain\brain-top-line-4.png" class="img12">

				<img src="brain\brain-raise-beg-firelines.png" class="img13">
				<img src="brain\brain-raise-beg-fire.png" class="img14">
				<img src="brain\brain-raise-beg-fire.png" class="img15">
				<img src="brain\brain-top-laser.png" class="img16">
				<img src="brain\brain-all-beg-fire.png" class="img17">
				<h1  id="ama" style="display: none"> Amateur</h1>



			</div>
		</a>
		<a href="check.php?option=3" >
			<div class="Professional">
				<div>
					<img src="brain\brain-top-base.png" class="img1"></div>

					<img src="brain\brain-river-beg-red.png" class="img2">
					<img src="brain\brain-river-beg-fire.png" class="img3">
					<img src="brain\brain-river-beg-blue.png" class="img4">


					<img src="brain\brain-top-synaps-1.png" class="img5">
					<img src="brain\brain-top-synaps-2.png" class="img6">
					<img src="brain\brain-top-synaps-3.png" class="img7">
					<img src="brain\brain-top-synaps-4.png" class="img8">
					<img src="brain\brain-top-line-1.png" class="img9">

					<img src="brain\brain-top-line-2.png" class="img10">
					<img src="brain\brain-top-line-3.png" class="img11">
					<img src="brain\brain-top-line-4.png" class="img12">

					<img src="brain\brain-raise-beg-firelines.png" class="img13">
					<img src="brain\brain-raise-beg-fire.png" class="img14">
					<img src="brain\brain-raise-beg-fire.png" class="img15">
					<img src="brain\brain-top-laser.png" class="img16">
					<img src="brain\brain-all-beg-fire.png" class="img17">

					<h1  id="prof" style="display: none"> Professional</h1>


				</div>
			</a>
			<script>
			var obj={};

			obj.textappear=function () {
				var te=this.querySelector("h1");
				te.style.display="block";
				te.style.color="white";
				// te.style.fontColor="white";
				// console.log(te.color.value);
			/* body... */}
			obj.textdisappear=function(){
				var im1=this.querySelector("h1");
				im1.style.display ="none";
			}

			var div1=document.querySelector(".beginner");
			div1.addEventListener("mouseover", obj.textappear,false);
			div1.addEventListener("mouseout",obj.textdisappear,false);
			var div2=document.querySelector(".Amateur");
			div2.addEventListener("mouseover", obj.textappear,false);
			div2.addEventListener("mouseout",obj.textdisappear,false);
			var div3=document.querySelector(".Professional");
			div3.addEventListener("mouseover", obj.textappear,false);
			div3.addEventListener("mouseout",obj.textdisappear,false);

			</script>
		</body>

		</html>
