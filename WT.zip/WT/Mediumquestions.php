<?php
  session_start();
  require 'login\db.php';
if($_SESSION['counter'] < 8){
  $n = mt_rand(1,25);
  $qrno  = $n;
  // if(isset($_GET['op'])){
  //   if(op == '1'){
  //     header("location: previous.php");
  //   }
  // $res = 0;
  // $prev = $_SESSION['qdone'][$index];
  // $ans = $mysqli->query("SELECT * FROM `mediumquestions` where qno = '$prev'")->fetch_assoc();
  $r = $mysqli->query("SELECT * FROM `mediumquestions` where qno = '$qrno'")->fetch_assoc();
  array_push($_SESSION['sessionquestions'],$r);
  $index = $_SESSION['prevcounter'];
  $q = $_SESSION['sessionquestions'][$index];
  array_push($_SESSION['correct'], $q['answer']);
  if(isset($_POST['answer'])){
    array_push($_SESSION['chosen'],$_POST['answer']);
  }
  $_SESSION['counter']++;
  $_SESSION['prevcounter']++;
}
// else{
//   $_SESSION['counter'] = 0;
//   header("location: tempresult.php");
// }
  ?>
  <?php
include 'h2.php';
 ?>
 <link type = "text/css" rel="stylesheet" href="try.css">
  <div class= "ques" style="border: none;">
    <div class= "side">
    </div>
    <div class="wrap">
      <p><?= $q['question']?>
        <br/><br/></p>
      </div>
      <div class = "ans">
        <?php
          if($_SESSION['counter'] != 8)
          echo '<form action = "mediumquestions.php" method = "POST">';
          else {
          echo '<form action = "result.php" method = "POST">';
          $_SESSION['counter'] = 0;
          }
         ?>
          <button class="btn-6" type = "submit" value="<?=$q['option1']?>" name = "answer"><?=$q['option1']?><span></span></button>
          <button class="btn-6" type = "submit" value="<?=$q['option2']?>" name = "answer"><?=$q['option2']?><span></span></button>
          <button class="btn-6" type = "submit" value="<?=$q['option3']?>" name = "answer"><?=$q['option3']?><span></span></button>
          <button class="btn-6" type = "submit" value="<?=$q['option4']?>" name = "answer"><?=$q['option4']?><span></span></button>
          <!-- <a href="login/logout.php" class="btn-6">Logout</a> -->
          <!-- <?php
            if($_SESSION['counter']!=1)
            echo '<a href="previous.php" class = "btn-6">Previous</a>';
            //$_SESSION['lastanswer'] = $_POST['answer'];
            ?> -->
        </form>
      </div>
    </div>
  </body>
  </html>
