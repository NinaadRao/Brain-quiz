<?php
    include "h2.php"
    ?> 
<html>
<head>
	<title></title>
</head>
<style type="text/css">
.beginner img {width:15%; height:auto; position:absolute; top:-10%; left:10%; padding: 10% 0% 0% 0%;  }
.top1 { animation-name: moving; animation-duration: 2s ;  display: inline-block; }
    .top4 {animation-name: neural; animation-duration: 2s; animation-delay: 6s;  opacity:0; animation-iteration-count: infinite;  }
    .top2 {    animation-name: neural; animation-duration: 2s; animation-delay: 2s;  opacity:0; animation-iteration-count: infinite; }
    .top3 {     animation-name: neural; animation-duration: 2s; animation-delay: 3s;  opacity:0; animation-iteration-count: infinite;}
     .top5 {    animation-name: neural; animation-duration: 2s; animation-delay: 4s;  opacity:0; animation-iteration-count: infinite;} 
    .top6 {      animation-name: neural; animation-duration: 2s; animation-delay:5s;  opacity:0; animation-iteration-count: infinite;}
    .top7 {      animation-name: neural; animation-duration: 2s; animation-delay: 6s;  opacity:0; animation-iteration-count: infinite;}
	.top8 {     animation-name: neural; animation-duration: 2s; animation-delay: 7s;  opacity:0; animation-iteration-count: infinite;}
    .top9 {       animation-name: neural; animation-duration: 2s; animation-delay: 8s;  opacity:0; animation-iteration-count: infinite;}
    .top10 {      animation-name: neural; animation-duration: 2s; animation-delay: 9s;  opacity:0; animation-iteration-count: infinite;}
    .top11 {     animation-name: neural; animation-duration: 2s; animation-delay: 9s;  opacity:0; animation-iteration-count: infinite;}
    .top12 {     animation-name: neural; animation-duration: 2s; animation-delay: 9s;  opacity:0; animation-iteration-count: infinite;}
@keyframes moving{
    0% { opacity: 0;  }
        5% {opacity: 0.05; }
     10% {opacity: 0.1;}
    15% {opacity: 0.15; }
    20% {opacity: 0.2; }
    25% {opacity: 0.25; }
    30% {opacity: 0.3; }
    35% {opacity: 0.35; }  
    40% {opacity: 0.4;}
    45% {opacity: 0.45;}
    50% {opacity: 0.5;} 
    55% {opacity: 0.55;}    
    60% {opacity: 0.6; }
    65% {opacity: 0.65; }
    70% {opacity: 0.7; }
    75% {opacity: 0.75; }
    80% {opacity: 0.8; }
    85% {opacity: 0.85; }
    90% {opacity: 0.9; }
    95% {opacity: 0.95; }
    100%   { opacity: 1;  }
}
	
    @keyframes neural{
    0% { opacity: 0;  }
    5% {opacity: 0.1; }
     10% {opacity: 0.2; }
    15% {opacity: 0.3; }
    20% {opacity: 0.4; }
    25% {opacity: 0.5; }
    30% {opacity: 0.6;}
    35% {opacity: 0.7;  }  
    40% {opacity: 0.8; }
    45% {opacity: 0.9; }
    50% {opacity: 1; } 
    55% {opacity: 0.9; }    
    60% {opacity: 0.8; }
    65% {opacity: 0.7; }
    70% {opacity: 0.6; }
    75% {opacity: 0.5;}
   80% {opacity: 0.4; }
    85% {opacity: 0.3; }
    90% {opacity: 0.2; }
    95% {opacity: 0.1; }
    100%   { opacity: 0;  }
}
	body {background: linear-gradient(rgba(0,0,0,0.9),rgba(0,0,0,0.8)); color:white;background-image: url("dark_spots_texture_background_50355_2558x1562.jpg");
background-position: 100% 0%;}
	p {font-size: 40px;}
	body{
width:100%;
height:100%;
background-repeat: repeat;
color:white;
margin:0 auto;
background-image: url("dark_spots_texture_background_50355_2558x1562.jpg");
background-position: 0px 0px;

animation: backAnimation infinite linear;
-ms-animation: backAnimation infinite linear ;
-moz-animation: backAnimation 30s infinite linear ;
-webkit-animation: backAnimation 30s infinite linear ;
}
@keyframes backAnimation {
from { background-position: 100% 0; }
to { background-position: 0 0; }
}
@-webkit-keyframes backAnimation {
from { background-position: 0 0; }
to { background-position: 100% 0; }
}
@-ms-keyframes backAnimation {
from { background-position: 0 0; }
to { background-position: 100% 0; }
}
@-moz-keyframes backAnimation {
from { background-position: 0 0; }
to { background-position: 100% 0; }
}
thead:hover+tbody{
    
    transition: all 0.5s ease-in;
}
#announce {
	opacity: 1;
    position: absolute;
    top:10%;
    left:40%;
	animation-name: moving;
	animation-duration: 2s;
}


#table {
    position: absolute;
    top:30%;
    left:35%;
}
</style>
<body>
	<p align="center" id="announce">Announcements</p>
<div align="center">
	<table border="1" bordercolor="grey" cellpadding="20" cellspacing="0" id="table">
		
		<thead style="color:#b5b5b5;">
			<tr>
				<th>DATE</th><th>ANNOUNCEMENT</th>
			</tr>
			
				
			
		</thead>
		<tbody>
			
			<tr style="background-color: black; color:white; text-align: center;">
				<td>13.08.2017</td>
				<td>Web design begins.</td>
			</tr>

			<tr>
				<td>1.09.2017</td>
				<td>1st review of the designed Webpage.</td>
			</tr>

			<tr style="background-color: black; color:white; text-align: center;">
				<td>10.10.2017</td>
				<td>Creation of Database</td>
			</tr>

			<tr style="text-align: center;">
				<td>14.11.2017</td>
				<td>Integration of work</td>
			</tr>
			<tr style="background-color: black; color:white; text-align: center;">
				<td>23.11.2017</td>
				<td>Launch of the webpage</td>
			</tr>


		</tbody>
	</table>
</div>
<div class="beginner">

    <a href="brainquiz.php"><div>

    <img src="brain\brain-front.png" class="top1"></div>
        
    <img src="brain\brain-front-blue.png" class="top2">    
    <img src="brain\brain-front-fire.png" class="top3">    
    <img src="brain\brain-front-fire-lines.png" class="top4">
     <img src="brain\brain-front-fire-lines-2.png" class="top5">
      <img src="brain\brain-front-line-1.png" class="top6">
<img src="brain\brain-front-line-2.png" class="top7">
<img src="brain\brain-front-line-3.png" class="top8">
 <img src="brain\brain-front-laser.png" class="top9">
 <img src="brain\brain-front-purple.png" class="top10">
 <img src="brain\brain-front-red.png" class="top11">

    
    <img src="brain\brain-front-synaps-2.png" class="top12">
   
    
        
        
    </div></a>
</body>
</html>