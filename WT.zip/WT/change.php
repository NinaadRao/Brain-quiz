

<!-- css -->
.t1{
	position:relative;
	float:right;
	width:50%;
	height:100%;
}
.b2{
	margin-bottom:200px;
	position:relative;
    top:100%;
	width:100%;
	height:50%;
	border:1px solid;
	border-color:green;
	background-color:#e3e3e3;
	padding:20px;
}
.t2{
	position:relative;
	float:left;
	width:50%;
	height:100%;
}







<!--add this just before footer-->
<div class="b2">
 <div class="t1"><p style="color:black;">HELP</p></div> 
 <div style="padding:20px" ><img src="win.png" style=" border:1px solid; border-color:black;"></div>
 
 </div> 
 <br>
 <div class="b2">
 <div class="t2"><p style="color:black;">ALL</p></div> 
 <div style="padding:20px"><img src="win.png" style=" border:1px solid; border-color:black; float:right;"></div>
 </div>
 
 <br>
 <div class="b2">
 <div class="t1"><p style="color:black;">ALL</p></div> 
 <div style="padding:20px"><img src="win.png" style=" border:1px solid; border-color:black;"></div>
 </div>
 
 <br>
 <div class="b2">
 <div class="t2"><p style="color:black;">ALL</p></div> 
 <div style="padding:20px"><img src="win.png" style=" border:1px solid; border-color:black; float:right;"></div>
 </div>