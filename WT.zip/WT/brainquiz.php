<?php
include 'h2.php';
?>

<link rel="stylesheet" href="homepage.css">
<style media="screen">
@font-face {
  font-family:"Arvo";
  src:url("fonts/arvo/Arvo-Bold.ttf");
}
body { background-image:url("dark_spots_texture_background_50355_2558x1562.jpg");
font-family: "Arvo";
margin:0; overflow-x: hidden;
color: white;
}
</style>
<div id="abouttext" style="text-align: center;">About the page</div>

<div height="20px" width="20px" class="brainff"><p id="braintext">BrainQuiz</p>
  <div class="brainfront1">



    <img src="brain\brain-front.png" class="brainfront" id="top1">

    <img src="brain\brain-front-blue.png" class="brainfront" id="top2" >
    <img src="brain\brain-front-fire.png" class="brainfront" id="top3">
    <img src="brain\brain-front-fire-lines.png" class="brainfront" id="top4">
    <img src="brain\brain-front-fire-lines-2.png" class="brainfront" id="top5">
    <img src="brain\brain-front-line-1.png" class="brainfront" id="top6">
    <img src="brain\brain-front-line-2.png" class="brainfront" id="top7">
    <img src="brain\brain-front-line-3.png" class="brainfront" id="top8">
    <img src="brain\brain-front-laser.png" class="brainfront" id="top9">
    <img src="brain\brain-front-purple.png" class="brainfront" id="top10">
    <img src="brain\brain-front-red.png" class="brainfront" id="top11">


    <img src="brain\brain-front-synaps-2.png" class="brainfront">
  </div>


  <!-- <img src="F:\\pes documents\\cs-3rd sem\\webtech\\brain\\brain-front.png" class="brainfront" > -->
</div>

<div class="slideshow-container">

  <div class="mySlides fade">

    <img src="images/image1.jpg" style="width:95% ;height:95%">

  </div>

  <div class="mySlides fade">
    <div class="text">Algorithm</div>
    <img src="images/image2.jpg" style="width:95%; height:95%">

  </div>

  <div class="mySlides fade">

    <img src="images/image3.jpg" style="width:95%; height:95%">
    <!--  <div class="text">Leaderboard</div> -->
  </div>



</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span>
  <span class="dot" onclick="currentSlide(2)"></span>
  <span class="dot" onclick="currentSlide(3)"></span>
</div>
<div id="mySidenav" class="sidenav">



  <div id="play" height="20px" width="75px">Go to Quiz</div>
</div>
<div id="aboutUs" class="about" >
  BrainQuiz redifines the way people imbibe knowldege changing it into a more trivia based system.It doesn't test you on what you already know but it gives you a chance to learn new things making it a fun and enriching exprience unlike any
  other you might have encountered before. BrainQuiz is like a blog, but isn't a blog, it's like a test website but it isn't one, it's a whole new way to try out what you know and how good you are at it and learn something new everyday since one of the greatest men of his time Mahtma Gandhi said that "Live as if you were to die tomorrow and learn as if you were to live forever". The process of learning should never stop and BrainQuiz is exactly meant for that so that the process of learning never stops with over 2000 questions to answer over 3 difficulties and categories like science, math and logic the learning curve only grows exponentially. With these many options you are bound to get hooked, this website is a gift which just keeps on giving.</div>

  <div class='parentdiv' style="background-image: url('images/background1.jpg');">
    <div class="child1" ontouchstart="this.classList.toggle('hover');">
      <div class="flipper">
        <div class="front">
          <img src="images/front1.jpg" height="300px" width="85%">
        </div>
        <div class="back">
          <img src="images/back1.jpg" height="300px" width="85%">
        </div>
      </div>
    </div>
    <div class="child2">
      <div class="first" style="color:black;">
        <p>Quizes help connect with nature. How so? Take a quiz find out</p>
        </div>
        <div class="second">
          <button type="submit" class = "button" data-hover="QUIZ" style="color:black;border: 2px solid black;"><span>STUCK?</span></button>
        </div>
      </div>
    </div>
    <div class='parentdiv' style="margin-top: 40px;background-image: url('images/background2.jpg');">
      <div class="child22">
        <div class="first">
          <p  style="color:white;">Who says Superheroes can't be smart? Did they take a quiz? Well, maybe they did? Take a quiz find out</p>
          </div>
          <div class="second">
            <a href = "animations.php"><button type="submit" class = "button" data-hover="QUIZ" style="color:white;border: 2px solid white"><span>HEROIC?</span></button></a>
          </div>
        </div>
        <div class="child11">
          <div class="flipper">
            <div class="front">
              <img src="images/front2.jpg" height="320px" width="85%">
            </div>
            <div class="back">
              <img src="images/back2.jpg" height="320px" width="85%">
            </div>
          </div>
        </div>
      </div>
      <div class='parentdiv' style="background-image: url('images/background3.jpg');">
        <div class="child1" ontouchstart="this.classList.toggle('hover');">
          <div class="flipper">
            <div class="front">
              <img src="images/front3.jpg" height="300px" width="85%">
            </div>
            <div class="back">
              <img src="images/back3.jpg" height="300px" width="85%">
            </div>
          </div>
        </div>
        <div class="child2">
          <div class="first" style="color: black;">
            <p>Some say doing well on a quiz can make you happy. Never experienced it? Don't trust them. Take a quiz find out</p>
            </div>
            <div class="second">
              <a href = "animations.php"><button type="submit" class = "button" data-hover="QUIZ" style="border: 2px solid black;color: black;"><span>HAPPY?</span></button></a>
            </div>
          </div>
        </div>
        <div class='parentdiv' style="background-image:url('images/background4.jpg'); margin-top: 48px;">
          <div class="child22">
            <div class="first">
              <p>A wise man once said.. Always hear that. Become the wise man. Take a quiz</p>
              </div>
              <div class="second">
                <a href = "animations.php"><button type="submit" class = "button" data-hover="QUIZ"><span>WISE?</span></button></a>
              </div>
            </div>
            <div class="child11">
              <div class="flipper">
                <div class="front">
                  <img src="images/front4.jpg" height="320px" width="85%">
                </div>
                <div class="back">
                  <img src="images/back4.jpg" height="320px" width="85%">
                </div>
              </div>
            </div>
          </div>
          <div class='parentdiv' style="background-image:url('images/background5.jpg');">
            <div class="child1" ontouchstart="this.classList.toggle('hover');">
              <div class="flipper">
                <div class="front">
                  <img src="images/front5.jpg" height="300px" width="85%">
                </div>
                <div class="back">
                  <img src="images/back5.jpg" height="300px" width="85%">
                </div>
              </div>
            </div>
            <div class="child2">
              <div class="first">
                <p style="color:black;">Did the billionares of today take the quizzes of yesterday. Did a quiz help them become what they are? Take a quiz find out</p>
              </div>
                <div class="second">
                  <a href='animations.php'><button type="submit" class = "button" data-hover="QUIZ" style="color: black; border: 2px solid black"><span>RICH?</span></button></a>
                </div>
              </div>
            </div>
      <?php
      include 'foot.php';
      include 'indicator.php';
      ?>
