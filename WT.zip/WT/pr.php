<?php
include 'h2.php';
include 'login/db.php';
$email = $_SESSION['email'];
$res = $mysqli->query("SELECT * FROM `users` where email = '$email'")->fetch_assoc();
$easy = $res['easy'];
$medium = $res['medium'];
$hard = $res['hard'];
$recent = "None";
$score = 0;
if(isset($_SESSION['option'])){
	if($_SESSION['option'] == 1){
		$recent = "EASY";
		$score = $_SESSION['easy'];
	}
	if($_SESSION['option'] == 2){
		$recent = "MEDIUM";
		$score = $_SESSION['medium'];
	}
	if($_SESSION['option'] == 3){
		$recent = "HARD";
		$score = $_SESSION['hard'];
	}
}
?>
<style>
@font-face {
	font-family:"Arvo";
	src:url("Arvo-Bold.ttf");
}

body { font-family: "Arvo";background-image: url("dark_spots_texture_background_50355_2558x1562.jpg");
-webkit-animation:backAnimation 30s infinite linear;
}
@-webkit-keyframes backAnimation{
	from {background-position: 100% 0;}
	to {background-position: 0 0;}
}
.wrap {
	position:absolute;
	left : 10%;
	top : 50%;
	height:60%;
	width: 25%;
	display : block;
	/*text-align:center;*/
}
.side
{   position : absolute;
	width: 10%;
	left:35%;
	width:15%;
	height : 60%;
	top:50%;
	display : block;
	/*text-align:center;*/
}
.ans{
	position : absolute;
	width: 10%;
	left:65%;
	width:25%;
	height : 70%;
	top:50%;
	display : block;
	/*text-align:center;*/
}
.nav{
	height:50px;
	display : block;
}
.name{
	position : absolute;
	width: 50%;
	left:20%;
	height : 20%;
	top:20%;
	display : block;
	text-align:center;
}

p{
	font-size:30px;
	color:white;

	padding:20px;
}

.wrap>p,.side>p {padding:10px;
}
/*
div{tab-size: 16;
border:1px solid;
border-color:green;
}*/
.ch{color:#1ab188;}
</style>
</head>
<body>
	<div class = "nav"></div>

	<div class = "name"><p><?=mb_strtoupper($_SESSION['first_name'])?></p></div>

	<div class="wrap"><p class="ch">CATEGORY</p> <p>BEGINNER</p> <p>AMATEUR</p> <p>PROFESSIONAL</p>
	</div>
	<div class="side"><p class="ch">SCORE</p> <p><?=$easy?></p>  <p><?=$medium?></p>  <p><?=$hard?></p></div>
</div>
<div class="ans"><p class="ch">RECENTLY ATTEMPTED</p> <p><?= $recent?><br>SCORE : <?=$score?></p><div>
	<img src="win.png" width="400px" height="100px">
</body>
</html>
