<?php
include("h2.php");
?>

<html>
<head>
	<title></title>
</head>]
<style type="text/css">
body {overflow-x: hidden;}
	.comp img { width:25%;  margin:40px 60px 40px 40px; border-radius: 25px; box-shadow: 5px 5px 5px rgba(255,255,255,0.5); height:auto;display: inline-block; -webkit-transform: scale(1);
  -moz-transform: scale(1);
  -o-transform: scale(1);
  transform: scale(1);
  transition: all 1s;
  -webkit-transition: all 1s;}
	.comp img:hover {
		-webkit-transform: scale(1.2);
  -moz-transform: scale(1.2);
  -o-transform: scale(1.2);
  transform: scale(1.2);
  transition: all 1s;
  -webkit-transition: all 1s;
	}
	
	.beginner img {width:12%; height:auto; position:fixed; top:-1%; left:85%;}
 body { background-image:url("dark_spots_texture_background_50355_2558x1562.jpg"); overflow-y: hidden; font-family: Verdana;}
 .top1 { animation-name: moving; animation-duration: 2s ;  display: inline-block; }
    .top4 {animation-name: neural; animation-duration: 2s; animation-delay: 6s;  opacity:0; animation-iteration-count: infinite;  }
    .top2 {    animation-name: neural; animation-duration: 2s; animation-delay: 2s;  opacity:0; animation-iteration-count: infinite; }
    .top3 {     animation-name: neural; animation-duration: 2s; animation-delay: 3s;  opacity:0; animation-iteration-count: infinite;}
     .top5 {    animation-name: neural; animation-duration: 2s; animation-delay: 4s;  opacity:0; animation-iteration-count: infinite;}
    .top6 {      animation-name: neural; animation-duration: 2s; animation-delay:5s;  opacity:0; animation-iteration-count: infinite;}
    .top7 {      animation-name: neural; animation-duration: 2s; animation-delay: 6s;  opacity:0; animation-iteration-count: infinite;}
	.top8 {     animation-name: neural; animation-duration: 2s; animation-delay: 7s;  opacity:0; animation-iteration-count: infinite;}
    .top9 {       animation-name: neural; animation-duration: 2s; animation-delay: 8s;  opacity:0; animation-iteration-count: infinite;}
    .top10 {      animation-name: neural; animation-duration: 2s; animation-delay: 9s;  opacity:0; animation-iteration-count: infinite;}
    .top11 {     animation-name: neural; animation-duration: 2s; animation-delay: 9s;  opacity:0; animation-iteration-count: infinite;}
    .top12 {     animation-name: neural; animation-duration: 2s; animation-delay: 9s;  opacity:0; animation-iteration-count: infinite;}
@keyframes moving{
    0% { opacity: 0;  }
        5% {opacity: 0.05; transform:scale(0.05,0.05);}
     10% {opacity: 0.1; transform: scale(0.1,0.1);}
    15% {opacity: 0.15; transform: scale(0.15,0.15);}
    20% {opacity: 0.2; transform: scale(0.2,0.2);}
    25% {opacity: 0.25; transform: scale(0.25,0.25);}
    30% {opacity: 0.3; transform: scale(0.3,0.3);}
    35% {opacity: 0.35; transform: scale(0.35,0.35); }
    40% {opacity: 0.4; transform: scale(0.4,0.4);}
    45% {opacity: 0.45; transform: scale(0.45,0.45);}
    50% {opacity: 0.5; transform: scale(0.5,0.5);}
    55% {opacity: 0.55; transform: scale(0.55,0.55);}
    60% {opacity: 0.6; transform: scale(0.6,0.6);}
    65% {opacity: 0.65; transform: scale(0.65,0.65);}
    70% {opacity: 0.7; transform: scale(0.7,0.7);}
    75% {opacity: 0.75; transform: scale(0.75,0.75);}
    80% {opacity: 0.8; transform: scale(0.8,0.8);}
    85% {opacity: 0.85; transform: scale(0.85,0.85);}
    90% {opacity: 0.9; transform: scale(0.9,0.9);}
    95% {opacity: 0.95; transform:  scale(0.95,0.95);}
    100%   { opacity: 1; transform:  scale(1,1); }
}

    @keyframes neural{
    0% { opacity: 0;  }
    5% {opacity: 0.1; }
     10% {opacity: 0.2; }
    15% {opacity: 0.3; }
    20% {opacity: 0.4; }
    25% {opacity: 0.5; }
    30% {opacity: 0.6;}
    35% {opacity: 0.7;  }
    40% {opacity: 0.8; }
    45% {opacity: 0.9; }
    50% {opacity: 1; }
    55% {opacity: 0.9; }
    60% {opacity: 0.8; }
    65% {opacity: 0.7; }
70% {opacity: 0.6; }
    75% {opacity: 0.5;}
   80% {opacity: 0.4; }
    85% {opacity: 0.3; }
    90% {opacity: 0.2; }
    95% {opacity: 0.1; }
    100%   { opacity: 0;  }
}
</style>
<body>
<div class="beginner">

    <a href="brainquiz.php"><div>

    <img src="brain\brain-front.png" class="top1"></div>

    <img src="brain\brain-front-blue.png" class="top2">
    <img src="brain\brain-front-fire.png" class="top3">
    <img src="brain\brain-front-fire-lines.png" class="top4">
     <img src="brain\brain-front-fire-lines-2.png" class="top5">
      <img src="brain\brain-front-line-1.png" class="top6">
<img src="brain\brain-front-line-2.png" class="top7">
<img src="brain\brain-front-line-3.png" class="top8">
 <img src="brain\brain-front-laser.png" class="top9">
 <img src="brain\brain-front-purple.png" class="top10">
 <img src="brain\brain-front-red.png" class="top11">


    <img src="brain\brain-front-synaps-2.png" class="top12">




    </div></a></div>
<div class="comp"><img src="comp1.png"><img src="comp2.png"><img src="comp3.png">
</div>
</body>
</html>