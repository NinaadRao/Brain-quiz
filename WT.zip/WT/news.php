<?php
include "h2.php"
?>

<html>
<head>
	<title>news</title>
</head>
<style type="text/css">
body {overflow-x: hidden}
	#xray { width: 40%;height:auto; position: absolute; top:20%; left:55%;}
	#holograms { width: 40%;height:auto; position: absolute; top:165%; left:55%;}
	#scientist { width: 40%;height:auto; position: absolute; top:95%; left:55%;}
	#heading {display:inline-block; margin-top:10px;margin-left:40px; margin-right:10px;color: orange; font-family: Helvetica;font-size: 20px; font-weight: bold; width:50%; -webkit-transform: scale(1);
  -moz-transform: scale(1);
  -o-transform: scale(1);
  transform: scale(1);
  transition: all 1s;
  -webkit-transition: all 1s;}
	#heading:hover {
-webkit-transform: scale(1.1);
  -moz-transform: scale(1.1);
  -o-transform: scale(1.1);
  transform: scale(1.1);
  transition: all 1s;
  -webkit-transition: all 1s;
	}
	#news {color:white; font-family: 'Ariel'; font-weight: normal; font-size: 18px;}
</style>
<body>
	<br>
<div id="heading">Stanford researchers built an algorithm that recognizes pneumonia better than human radiologists<br><br><div id='news'>A group of Stanford researchers says it has built an algorithm that can diagnose pneumonia in chest x-rays better than the average human radiologists.

The group, which includes deep learning researcher Andrew Ng, developed the algorithm using more than 112,000 chest x-rays released by the National Institutes of Health in September. A little over a month later, the algorithm could identify 14 types of medical conditions and diagnose pneumonia better than a group of four radiologists.

The researchers published their results in a paper (PDF) posted the open access website arXiv.  

“Automated detection of diseases from chest X-rays at the level of expert radiologists would not only have tremendous benefit in clinical settings, it would be invaluable in [the] delivery of healthcare to populations with inadequate access to diagnostic imaging specialists,” the researchers wrote.

Pranav Rajpurkar, a graduate student in the Stanford Machine Learning Group who co-authored the paper, told Stanford News the algorithm can help radiologists detect an illness that is difficult to diagnose but hospitalizes more than 1 million people each year, according to the Centers for Disease Control and Prevention. The group has done similar work developing and testing algorithms that can identify heart arrhythmias.</div>
</div>
<img id="xray" src="xray_doc.jpg">
<br><br><br>
<hr>
<br><br>
<div id="heading">New research shows explaining things to ‘normal’ people can help scientists be better at their jobs<br><br><div id="news">In times when fake news and alternative facts circulate in society, spreading scientifically based findings is more important than ever. This makes science communication one of academia’s most vital tasks. But despite the pivotal role scientific communication plays in society, communicating with the general public is not always prioritised among researchers.

This is in part because although scientists tend to be great at doing the research and discovering results, they are not always so great at then communicating these findings to a wider audience. Writing about research for people outside academia requires a wider perspective on science matters, and a completely different writing style. And many scientists may simply not know how to communicate their research to wider society. The low importance placed on this in the past, and the limited (if any) training students get in science education also isn’t helping.

This is shortsighted, particularly as my recent study found, encouraging science students to write about their work for a non academic audience helped them to discover and discuss different ideas within their thesis. And this in turn, helped them to realise the importance and societal impact of their work.</div></div>
<img id="scientist" src="scientist.jpg">

<br><br><br>
<hr>
<br><br>
<div id="heading">Engineers Use Machine Learning to Reconstruct Holograms and Improve Optical Microscopy<br><br><div id='news'>A form of machine learning called deep learning is one of the key technologies behind recent advances in applications like real-time speech recognition and automated image and video labeling.

The approach, which uses multi-layered artificial neural networks to automate data analysis, also has shown significant promise for health care: It could be used, for example, to automatically identify abnormalities in patients' X-rays, CT scans and other medical images and data.

In two new papers, UCLA researchers report that they have developed new uses for deep learning: reconstructing a hologram to form a microscopic image of an object and improving optical microscopy.

Their new holographic imaging technique produces better images than current methods that use multiple holograms, and it's easier to implement because it requires fewer measurements and performs computations faster.

The research was led by Aydogan Ozcan, an associate director of the UCLA California NanoSystems Institute and the Chancellor's Professor of Electrical and Computer Engineering at the UCLA Henry Samueli School of Engineering and Applied Science; and by postdoctoral scholar Yair Rivenson and graduate student Yibo Zhang, both of UCLA's electrical and computer engineering department.




Another advantage of the new approach was that it was achieved without any modeling of light-matter interaction or a solution of the wave equation, which can be challenging and time-consuming to model and calculate for each individual sample and form of light.


</div></div>
<img id="holograms" src="holograms.jpg"><br><br><br>
<hr>
</body>
</html>